/*Resources (all in “arbitrary units”):
Water (H2O)
Carbon dioxide (CO2)
Nitrogen (ammonia, NH3, is an available form of nitrogen)
LOW-ENERGY? NADP+
HIGH-ENERGY? NADPH
ATP <-(+/- Water)-> ADP
Glucose
Your energy reserves are growing low. (show “energy” (ATP, C10H16N5O13P3) becoming “spent energy” (ADP, C10H15N5O10P2))
break down starch into maltose or glucose
Cellularly respire in cotyledon to gain ATP
1 C6H12O6, 6O2 -> 6CO2, 6H2O, 34 ATP
*/
import {getNonNullElement, createDefinedSpan, newTextEvent, addButtonListener, createDefinedSpanColored} from "./main";

let H2O = 0; //water
//let CO2 = 0; //carbon dioxide - CO2
//let O2 = 0; //oxygen gas - enters passively via diffusion in seed forme?
let ATP = 34; //adenosine triphosphate - ATP
let ADP = 0; //adenosine diphosphate - ADP - C10H15N5O10P2 - made using 5 ammonia, 10 CO2, and phosphorous
let starch = 100; // starch - (C6H10O5)n
let glucose = 0; //glucose - C6H12O6
//let NH3 = 0; //ammonia with nitrogen in it
//store all of this in window.localStorage

let amylaseRate = 0;
let starchToGlucose = false;

let initRespiration = false;

function changeH2O(numToAdd : number){
    H2O += numToAdd;
    getNonNullElement("water_counter").textContent = ""+H2O;
}

function changeATP(numToAdd : number){
    ATP += numToAdd;
    getNonNullElement("energy_counter").textContent = ""+ATP;
}

function changeADP(numToAdd : number){
    ADP += numToAdd;
    getNonNullElement("spent_energy_counter").textContent = ""+ADP;
}

function changeStarch(numToAdd : number){
    starch += numToAdd;
    getNonNullElement("starch_counter").textContent = ""+starch;
}

function changeGlucose(numToAdd : number){
    glucose += numToAdd;
    getNonNullElement("glucose_counter").textContent = ""+glucose;
}

function addH2OTesta(){
    //display the resources tab if it isn't shown already
    const rsc = document.getElementById("resources_sector");
    if(rsc === null){
        throw "resources sector is gone somehow?";
    }
    if(rsc.style.opacity != "1"){
        rsc.style.opacity = "1";
        showResource("Water", "H<sub>2</sub>O", 1);
    }
    
    //degrade the testa the more water you uptake with it
    if(document.getElementById("dry_INTRO")){
        const introText = getNonNullElement("dry_INTRO");
    
        if(H2O >= 20){
            introText.style.opacity = "0.85";
            introText.textContent = "Your ";
            introText.appendChild(createDefinedSpan("testa", "seed coating"));
            introText.appendChild(document.createTextNode(" is beginning to break down."));
        }
        if(H2O >= 40){
            introText.style.opacity = "0";
            setTimeout(() => { introText.remove(); }, 1000);
            newTextEvent("Deep in your cells, <span>RNA|‘r’ibo’n’ucleic ‘a’cid, a single-stranded molecule with many different forms that all help in protein synthesis,</span> conveys instructions from your <span>DNA|‘d’eoxyribo’n’ucleic ‘a’cid, a double-stranded molecule that stores information,</span> to produce <span>amylase|a protein that helps break down starches</span>. This uses energy.");
            showResource("Energy","ATP, C<sub>10</sub>H<sub>16</sub>N<sub>5</sub>O<sub>13</sub>P<sub>3</sub>", ATP);
            showResource("Spent Energy","ADP, C<sub>10</sub>H<sub>15</sub>N<sub>5</sub>O<sub>10</sub>P<sub>2</sub>", ADP);
            initialAmylaseProduction();
        }
        
    }
    //increment H2O
    changeH2O(1);
}

function initialAmylaseProduction(){
    //when energy at 10, say "Your energy reserves are growing low."
    if(ATP == 10){
        newTextEvent("Your energy reserves are growing low.");
    }
    //when all energy is converted to spent energy, prompt the visibility of the switch for
    //  glucose production and say
    //"Amylase production concludes. You now have enough amylase to convert starches to glucose."
    if(ATP == 0){
        newTextEvent("<span>Amylase|A protein that helps break down starches</span> production concludes. You now have enough <span>amylase|proteins that help break down starches</span> to convert starches to glucose.");
        amylaseRate = 0;
        changeAmylaseRate(1); //amylaseRate is now 1
        showResource("Starch","long chains of sugars", starch);
        getNonNullElement("glucose_production").style.opacity = ""+1; //show the toggle button
        addButtonListener("glucose_production", "glucose_production", 1);
        getNonNullElement("amylase_counter").style.opacity = "1";
        getNonNullElement("glucose_production_description").style.opacity = "1";
    }
    else{
        //energy -> spent energy once per second
        changeATP(-1);
        changeADP(1);
        setTimeout(() => {
            initialAmylaseProduction();    
        }, 1000);
    }

}

function changeAmylaseRate(numIncrease : number){
    amylaseRate += numIncrease;
    getNonNullElement("amylase_counter").textContent = "Amylase: "+amylaseRate;
    getNonNullElement("glucose_production_description").textContent = "Per second: turns "+amylaseRate+" starch into "+(amylaseRate*10)+" glucose"
}

function toggleGlucoseProduction(){
    if(starchToGlucose){
        starchToGlucose = false;
        getNonNullElement("glucose_production").textContent = "Toggle Glucose Production ON";
    }
    else{
        starchToGlucose = true;
        if(document.getElementById("glucose_counter") == null){
            showResource("Glucose","a simple sugar, C<sub>6</sub>H<sub>12</sub>O<sub>6</sub>", glucose);
        }
        getNonNullElement("glucose_production").textContent = "Toggle Glucose Production OFF";
    }
}

function glucoseProduction(){
    if(starchToGlucose){
        changeStarch(-1*amylaseRate); changeGlucose(10*amylaseRate); //turn x starch into 10x glucose
        if(!initRespiration && glucose >= 100) { //the first time glucose goes above 100...
            initRespiration = true;
            console.log(initRespiration); //debug

            let respireText = getNonNullElement("respire_text");  
            respireText.textContent="Requires 1 glucose, ";
            respireText.appendChild(createDefinedSpanColored("6 oxygen gas", "6 oxygen gas (currently able to diffuse into your respiring cells from the soil)", { r: 150, g: 150, b: 150 }));
            respireText.appendChild(document.createTextNode(", and 1 ADP"));
            respireText.appendChild(document.createElement("br"));
            respireText.appendChild(document.createTextNode("Produces "));
            respireText.appendChild(createDefinedSpanColored("6 carbon dioxide", "6 carbon dioxide (currently able to diffuse into the soil from your respiring cells)", { r: 150, g: 150, b: 150 }));
            respireText.appendChild(document.createTextNode(", 6 water, and 1 ATP"));
        }

        //do this once a second
        setTimeout(() => {
            glucoseProduction();    
        }, 1000);
    }
}

function showResource(resource : string, chemTitle : string, startingNum : number){
    const tableSection = getNonNullElement("resources_list");
    const newRow = document.createElement("tr");

    //give the resource cell the appropriate label
    const label = document.createElement("td");
    label.textContent = resource;

    //give the chemTitle cell the appropriate label, including subscripts
    const chemLabel = document.createElement("td");
    if(!chemTitle.includes("<sub>")){
        chemLabel.textContent = chemTitle;
    }
    else{
        //an integer representing the starting index of the first <sub> token
        let posOfSubscript = chemTitle.indexOf("<sub>");
        while(posOfSubscript>=0){ //while there's another subscript token
            //make the label have some plain text
            chemLabel.appendChild(document.createTextNode(chemTitle.substring(0,posOfSubscript)));

            //make the label have some subscript text
            let posOfEndSubscript = chemTitle.indexOf("</sub>");
            if(posOfEndSubscript<0){
                throw new Error('chemTitle contained a starting "<sub>" token, but no ending "</sub>" token');
            }
            const subText = document.createElement("sub");
            subText.textContent = chemTitle.substring(posOfSubscript+5,posOfEndSubscript);
            chemLabel.appendChild(subText);

            //update chemTitle and posOfSubscript
            chemTitle = chemTitle.substring(posOfEndSubscript+6);
            posOfSubscript = chemTitle.indexOf("<sub>");
        }
        //put whatever remains of chemTitle into chemLabel 
        chemLabel.appendChild(document.createTextNode(chemTitle));
    }

    //give the number cell the appropriate starting value and label
    const num = document.createElement("td");
    num.textContent = ""+startingNum;
    num.id = ""+resource.normalize().toLowerCase().replaceAll(" ", "_")+"_counter";
    
    newRow.appendChild(label);
    newRow.appendChild(chemLabel);
    newRow.appendChild(num);
    tableSection.appendChild(newRow);
}

function saveResources(){ //called by main every few seconds to save the game
    window.localStorage.setItem("H2O", ""+H2O);
    window.localStorage.setItem("ATP", ""+ATP);
    window.localStorage.setItem("ADP", ""+ADP);
    window.localStorage.setItem("starch", ""+starch);
    window.localStorage.setItem("glucose", ""+glucose);

    window.localStorage.setItem("amylaseRate", ""+amylaseRate);
    window.localStorage.setItem("starchToGlucose", ""+starchToGlucose);

    window.localStorage.setItem("initRespiration", ""+initRespiration);
        //KEEP TRACK OF SHOWN RESOURCES
}
function loadResources(){
    //RE-SHOW RESOURCES
}

export{addH2OTesta, changeH2O, amylaseRate, starchToGlucose, toggleGlucoseProduction, glucoseProduction, saveResources}